# MDManage Frontend Test Data Setup Guide

## Overview

This guide provides instructions for setting up the required test data for the MDManage frontend automation test scripts. Proper test data setup ensures reliable and consistent test execution.

## Prerequisites

### Backend Services
- All backend services must be running
- Database must be accessible
- API endpoints must be responding
- Authentication service must be functional

### Database Setup
- Test database should be clean or have known state
- Required tables should exist
- Proper permissions should be set

## Required Test Data

### 1. Authentication Data

#### Admin User
```json
{
  "username": "admin",
  "password": "password123",
  "email": "admin@example.com",
  "firstName": "Admin",
  "lastName": "User",
  "role": "SUPER_ADMIN",
  "type": "INTERNAL",
  "location": "MAIN",
  "isActive": true,
  "mfaEnabled": false
}
```

#### Test Users (Optional)
```json
{
  "username": "testuser",
  "password": "TestPass123!",
  "email": "test@example.com",
  "firstName": "Test",
  "lastName": "User",
  "role": "STAFF",
  "type": "INTERNAL",
  "location": "MAIN",
  "isActive": true,
  "mfaEnabled": false
}
```

### 2. Practice Data

#### Test Practice
```json
{
  "practiceId": "PRAC001",
  "practiceName": "Test Medical Center",
  "doctor": "Dr. Jane Smith",
  "email": "info@testmedical.com",
  "address1": "123 Medical Drive",
  "address2": "Suite 100",
  "city": "New York",
  "state": "NY",
  "zip": "10001",
  "tin": "12-3456789",
  "phone": "555-123-4567",
  "fax": "555-123-4568",
  "header": "Test Medical Center - Quality Care",
  "footer": "Thank you for choosing our services"
}
```

### 3. Insurance Data

#### Test Insurance Company
```json
{
  "id": "INS001",
  "name": "Test Insurance Company",
  "address": "456 Insurance Street",
  "city": "Insurance City",
  "state": "IC",
  "zip": "12345",
  "phone": "555-987-6543",
  "fax": "555-987-6544",
  "email": "info@testinsurance.com"
}
```

### 4. Patient Data

#### Test Patient
```json
{
  "patientId": "PAT001",
  "firstName": "John",
  "lastName": "Doe",
  "initial": "M",
  "address": "123 Main Street",
  "city": "New York",
  "state": "NY",
  "zip": "10001",
  "phone": "555-123-4567",
  "sex": "M",
  "dob": "1990-01-15",
  "firstVisit": "2024-01-15",
  "practiceId": "PRAC001",
  "insuranceDetails": {
    "policyHolderFirstName": "John",
    "policyHolderLastName": "Doe",
    "policyHolderAddress": "123 Main Street",
    "policyHolderCity": "New York",
    "policyHolderState": "NY",
    "policyHolderZip": "10001",
    "policyHolderPhone": "555-123-4567"
  },
  "primaryInsurance": {
    "insuranceType": "PRIMARY",
    "insuranceCompany": "INS001",
    "policyNumber": "POL001",
    "claimNumber": "CLM001",
    "relationship": "SELF",
    "dateOfAccident": "2024-01-01",
    "adjusterName": "Jane Adjuster",
    "adjusterFax": "555-123-4568",
    "insurancePhone": "555-123-4569",
    "insuranceFax": "555-123-4570",
    "notes": "Primary insurance coverage details"
  }
}
```

### 5. Letter Template Data

#### Test Letter Template
```json
{
  "templateName": "Test Letter Template",
  "category": "Insurance",
  "fields": ["patientId", "amount", "dos", "insuranceCompany"],
  "templateContent": "Dear {insuranceCompany},\\n\\nThis is a test letter template for patient {patientId}.\\n\\nAmount: ${amount}\\nDate of Service: {dos}\\n\\nSincerely,\\n{providerName}",
  "isActive": true,
  "isDefault": false
}
```

### 6. Fax Data

#### Test Fax Number
```json
{
  "companyName": "Test Company",
  "faxNumber": "555-123-4567",
  "typeNumber": "Primary",
  "practice": "PRAC001",
  "user": "admin",
  "isActive": true
}
```

### 7. DMS (Document Management System) Data

#### Test Document Folders
```json
{
  "folderName": "PAT001_20240115",
  "practiceId": "PRAC001",
  "patientId": "PAT001",
  "createdBy": "admin",
  "isActive": true
}
```

#### Test Document Types
```json
{
  "id": "DOC001",
  "name": "Insurance Letter",
  "category": "Insurance",
  "isActive": true,
  "description": "Insurance-related documents"
}
```

#### Test Document Segregation
```json
{
  "patientName": "John Doe",
  "patientId": "PAT001",
  "fromDate": "2024-01-01",
  "toDate": "2024-01-31",
  "pageNumbers": [1, 2, 3],
  "practiceId": "PRAC001"
}
```

#### Test E-Files
```json
{
  "filename": "07022025-07022025-Insurance-07_31_2025.pdf",
  "filepath": "/documents/PAT001/07022025-07022025-Insurance-07_31_2025.pdf",
  "patientId": "PAT001",
  "practiceId": "PRAC001",
  "documentType": "Insurance",
  "uploadedAt": "2024-01-15T10:30:00Z",
  "fileSize": "1024000"
}
```

## Database Setup Scripts

### SQL Setup Script
```sql
-- Create test database (if needed)
CREATE DATABASE IF NOT EXISTS mdmanage_test;

-- Use test database
USE mdmanage_test;

-- Insert admin user
INSERT INTO users (username, password, email, first_name, last_name, role, type, location, is_active, mfa_enabled, created_at, updated_at)
VALUES ('admin', '$2a$10$encrypted_password', 'admin@example.com', 'Admin', 'User', 'SUPER_ADMIN', 'INTERNAL', 'MAIN', true, false, NOW(), NOW());

-- Insert test practice
INSERT INTO practices (practice_id, practice_name, doctor, email, address1, address2, city, state, zip, tin, phone, fax, header, footer, created_at, updated_at)
VALUES ('PRAC001', 'Test Medical Center', 'Dr. Jane Smith', 'info@testmedical.com', '123 Medical Drive', 'Suite 100', 'New York', 'NY', '10001', '12-3456789', '555-123-4567', '555-123-4568', 'Test Medical Center - Quality Care', 'Thank you for choosing our services', NOW(), NOW());

-- Insert test insurance company
INSERT INTO insurance_companies (id, name, address, city, state, zip, phone, fax, email, created_at, updated_at)
VALUES ('INS001', 'Test Insurance Company', '456 Insurance Street', 'Insurance City', 'IC', '12345', '555-987-6543', '555-987-6544', 'info@testinsurance.com', NOW(), NOW());

-- Insert test patient
INSERT INTO patients (patient_id, first_name, last_name, initial, address, city, state, zip, phone, sex, dob, first_visit, practice_id, created_at, updated_at)
VALUES ('PAT001', 'John', 'Doe', 'M', '123 Main Street', 'New York', 'NY', '10001', '555-123-4567', 'M', '1990-01-15', '2024-01-15', 'PRAC001', NOW(), NOW());

-- Insert test letter template
INSERT INTO letter_templates (template_name, category, fields, template_content, is_active, is_default, created_at, updated_at)
VALUES ('Test Letter Template', 'Insurance', 'patientId,amount,dos,insuranceCompany', 'Dear {insuranceCompany},\\n\\nThis is a test letter template for patient {patientId}.\\n\\nAmount: ${amount}\\nDate of Service: {dos}\\n\\nSincerely,\\n{providerName}', true, false, NOW(), NOW());

-- Insert test fax number
INSERT INTO fax_numbers (company_name, fax_number, type_number, practice_id, user_id, is_active, created_at, updated_at)
VALUES ('Test Company', '555-123-4567', 'Primary', 'PRAC001', 'admin', true, NOW(), NOW());

-- Insert test document folders
INSERT INTO document_folders (folder_name, practice_id, patient_id, created_by, is_active, created_at, updated_at)
VALUES ('PAT001_20240115', 'PRAC001', 'PAT001', 'admin', true, NOW(), NOW());

-- Insert test document types
INSERT INTO document_types (id, name, category, is_active, description, created_at, updated_at)
VALUES ('DOC001', 'Insurance Letter', 'Insurance', true, 'Insurance-related documents', NOW(), NOW());

-- Insert test e-files
INSERT INTO e_files (filename, filepath, patient_id, practice_id, document_type, uploaded_at, file_size, created_at, updated_at)
VALUES ('07022025-07022025-Insurance-07_31_2025.pdf', '/documents/PAT001/07022025-07022025-Insurance-07_31_2025.pdf', 'PAT001', 'PRAC001', 'Insurance', '2024-01-15 10:30:00', 1024000, NOW(), NOW());
```

## API Setup Scripts

### REST API Setup
```bash
# Create admin user
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123",
    "email": "admin@example.com",
    "firstName": "Admin",
    "lastName": "User",
    "role": "SUPER_ADMIN",
    "type": "INTERNAL",
    "location": "MAIN",
    "isActive": true,
    "mfaEnabled": false
  }'

# Create test practice
curl -X POST http://localhost:8080/api/practices \
  -H "Content-Type: application/json" \
  -d '{
    "practiceId": "PRAC001",
    "practiceName": "Test Medical Center",
    "doctor": "Dr. Jane Smith",
    "email": "info@testmedical.com",
    "address1": "123 Medical Drive",
    "address2": "Suite 100",
    "city": "New York",
    "state": "NY",
    "zip": "10001",
    "tin": "12-3456789",
    "phone": "555-123-4567",
    "fax": "555-123-4568",
    "header": "Test Medical Center - Quality Care",
    "footer": "Thank you for choosing our services"
  }'
```

## Test Data Validation

### Validation Script
```javascript
// Validate test data exists
const validateTestData = async () => {
  const endpoints = [
    '/api/users/admin',
    '/api/practices/PRAC001',
    '/api/insurance/INS001',
    '/api/patients/PAT001',
    '/api/templates/test-letter-template',
    '/api/fax-numbers/test-company'
  ];
  
  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`http://localhost:8080${endpoint}`);
      if (!response.ok) {
        console.error(`Missing test data: ${endpoint}`);
      } else {
        console.log(`✓ Test data exists: ${endpoint}`);
      }
    } catch (error) {
      console.error(`Error validating ${endpoint}:`, error);
    }
  }
};
```

## Test Data Cleanup

### Cleanup Script
```sql
-- Clean up test data after test execution
DELETE FROM fax_numbers WHERE company_name = 'Test Company';
DELETE FROM letter_templates WHERE template_name = 'Test Letter Template';
DELETE FROM patients WHERE patient_id = 'PAT001';
DELETE FROM insurance_companies WHERE id = 'INS001';
DELETE FROM practices WHERE practice_id = 'PRAC001';
DELETE FROM users WHERE username = 'testuser';
-- Note: Do not delete admin user as it's required for tests
```

## Environment Configuration

### Environment Variables
```bash
# Test environment configuration
export TEST_DB_URL="jdbc:mysql://localhost:3306/mdmanage_test"
export TEST_DB_USERNAME="test_user"
export TEST_DB_PASSWORD="test_password"
export TEST_API_BASE_URL="http://localhost:8080/api"
export TEST_FRONTEND_URL="http://localhost:5173"
export TEST_ADMIN_USERNAME="admin"
export TEST_ADMIN_PASSWORD="password123"
```

### Configuration Files
```yaml
# test-config.yml
database:
  url: "jdbc:mysql://localhost:3306/mdmanage_test"
  username: "test_user"
  password: "test_password"

api:
  base_url: "http://localhost:8080/api"
  timeout: 30000

frontend:
  url: "http://localhost:5173"
  timeout: 20000

test_data:
  admin_username: "admin"
  admin_password: "password123"
  test_practice_id: "PRAC001"
  test_patient_id: "PAT001"
  test_insurance_id: "INS001"
```

## Troubleshooting

### Common Issues

#### 1. Database Connection Issues
**Issue**: Cannot connect to test database
**Solution**:
- Verify database is running
- Check connection credentials
- Ensure database exists
- Verify network connectivity

#### 2. API Endpoint Issues
**Issue**: API endpoints not responding
**Solution**:
- Verify backend services are running
- Check API endpoint URLs
- Verify authentication
- Check API documentation

#### 3. Test Data Not Found
**Issue**: Test data missing or incorrect
**Solution**:
- Run setup scripts again
- Verify data insertion
- Check database constraints
- Validate data format

#### 4. Authentication Issues
**Issue**: Cannot authenticate with test credentials
**Solution**:
- Verify admin user exists
- Check password encryption
- Verify user is active
- Check role permissions

### Debug Commands

```bash
# Check database connection
mysql -u test_user -p -h localhost mdmanage_test

# Check API endpoints
curl -X GET http://localhost:8080/api/health

# Check frontend
curl -X GET http://localhost:5173

# Check test data
curl -X GET http://localhost:8080/api/users/admin
```

## Best Practices

### Data Management
1. **Use unique identifiers** for test data
2. **Clean up after tests** to avoid conflicts
3. **Use consistent naming** conventions
4. **Validate data integrity** regularly
5. **Document data dependencies**

### Security
1. **Use test-specific credentials**
2. **Isolate test data** from production
3. **Use minimal permissions** for test users
4. **Encrypt sensitive data** appropriately
5. **Regular security audits**

### Maintenance
1. **Update test data** when schema changes
2. **Version control** test data scripts
3. **Automate setup** and cleanup
4. **Monitor data consistency**
5. **Regular backups** of test data

## Support

For issues with test data setup:
1. Check the troubleshooting section
2. Verify all prerequisites are met
3. Check database and API logs
4. Contact the development team
5. Review the test execution guide
